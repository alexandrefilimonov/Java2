package ru.geekbrains.Lesson1;

public class Entry
{
    protected String _name, _phone;
    public Entry(String n, String p) { _name = n; _phone = p; }
    public String name() { return _name; }
    public String phone() { return _phone; }
}
