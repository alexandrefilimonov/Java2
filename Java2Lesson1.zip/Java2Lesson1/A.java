public class A implements IClassNameInterface
{
    private String value = "A";
    public String getClassName() {
        return this.value;
    }

}


