public class C extends A 
{
    public String getClassName() {
        return "C";
    }
}


