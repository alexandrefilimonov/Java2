public interface IClassNameInterface   
{
    String getClassName();

}


